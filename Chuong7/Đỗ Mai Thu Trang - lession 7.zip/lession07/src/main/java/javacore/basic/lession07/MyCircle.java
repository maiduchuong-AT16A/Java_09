/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lession07;

/**
 *
 * @author Admin
 */
import java.util.*;
import java.lang.*;
import java.text.DecimalFormat;

public class MyCircle {

    private MyPoint center;
    private double r;

    public MyCircle() {

    }

    public MyCircle(double x, double y, double r) {
        this.center = new MyPoint(x, y);
        this.r = r;
    }

    public MyCircle(MyPoint center, double r) {
        this.center = center;
        this.r = r;
    }

    public MyPoint getCenter() {
        return center;
    }

    public void setCenter(MyPoint center) {
        this.center = center;
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }

    public double getCircumference() {
        return 2 * Math.PI * r;
    }

    public double getArea() {
        return Math.PI * r * r;
    }
    
    DecimalFormat df = new DecimalFormat("#.###");
    @Override
    public String toString() {
        return "Circle info: " + center.toString() + ", radius = " + r + ", circumference = " + df.format(getCircumference()) + ", area = " + df.format(getArea());
    }
}
