/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package javacore.basic.lession07;

/**
 *
 * @author Admin
 */
public class Lession07 {

    public static void main(String[] args) {

    }
}
