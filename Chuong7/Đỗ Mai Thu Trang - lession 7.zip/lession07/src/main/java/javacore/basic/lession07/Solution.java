/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lession07;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Solution {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for (int t = 0; t < T; t++) {
            int n = sc.nextInt();
            double[] pt = new double[2 * n];
            for (int l = 0; l < 2 * n; l++) {
                pt[l] = sc.nextDouble();
            }

            int k = sc.nextInt();
            double x1 = sc.nextDouble();
            double y1 = sc.nextDouble();
            MyPoint[] pts = new MyPoint[n];
            for (int l = 0; l < n; l++) {
                pts[l] = new MyPoint(pt[2 * l], pt[2 * l + 1]);
            }

            int p = sc.nextInt();

            int m = sc.nextInt();
            double[] cc = new double[2 * m];
            double[] r = new double[m];
            for (int l = 0; l < 2 * m; l++) {
                cc[l] = sc.nextDouble();
            }
            for (int l = 0; l < m; l++) {
                r[l] = sc.nextDouble();
            }

            int q = sc.nextInt();
            MyCircle[] ccs = new MyCircle[m];
            for (int l = 0; l < m; l++) {
                ccs[l] = new MyCircle(cc[2 * l], cc[2 * l + 1], r[l]);
            }

            int i = sc.nextInt();
            int j = sc.nextInt();

            System.out.println("Case #" + (t + 1) + ":");
            System.out.printf("distance = %.3f\n", pts[k].getDistance(x1, y1));
            System.out.println(pts[p]);
            System.out.println(ccs[q]);
            if (ccs[i].getCenter().getDistance(ccs[j].getCenter().getX(), ccs[j].getCenter().getY()) < (ccs[i].getR() + ccs[j].getR())) {
                System.out.println("Circle " + i + " intersects with Circle " + j);
            } else if (ccs[j].getCenter().getDistance(ccs[i].getCenter().getX(), ccs[i].getCenter().getY()) < (ccs[j].getR() + ccs[i].getR())) {
                System.out.println("Circle " + j + " intersects with Circle " + i);
            } else {
                System.out.println("Circle " + i + " does not intersect with Circle " + j);
            }
        }
    }
}
