
package com.mycompany.testproject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TestProject 
{
    static void insertValueHCN(HinhChuNhat arr[],byte M,Scanner sc)
    {
        double a,b;
        for(int i = 0; i < M; i++)
        {
            a = sc.nextDouble();
            b = sc.nextDouble();
            HinhChuNhat hcn = new HinhChuNhat(a, b);
            arr[i] = hcn;
        }
    }
    static void insertValueHT(HinhTron arr2[],byte N,Scanner sc)
    {
        double r;
        for(int i = 0; i < N; i++)
        {
            r = sc.nextDouble();
            HinhTron ht = new HinhTron(r);
            arr2[i] = ht;
        }
    }
    static void showHCN(HinhChuNhat arr[],byte P,Scanner sc)
    {
        byte a;
        for(int i = 0; i < P; i++)
        {
            a = sc.nextByte();
            arr[a].xuatThongTin();
        }
    }
    static void showHT(HinhTron arr[],byte Q,Scanner sc)
    {
        byte a;
        for(int i = 0; i < Q; i++)
        {
            a = sc.nextByte();
            arr[a].xuatThongTin();
        }
    }
    public static void main(String[] args) throws FileNotFoundException 
    {
        System.setIn(new FileInputStream("Input.txt"));
        Scanner sc = new Scanner(System.in);
        byte T = sc.nextByte();
        byte M,N,P,Q;
        for(int t = 0; t < T; t++)
        {
            System.out.printf("Case #%d:\n",t+1);
            M = sc.nextByte();
            N = sc.nextByte();
            P = sc.nextByte();
            Q = sc.nextByte();
            HinhChuNhat arr[] = new HinhChuNhat[M];
            HinhTron arr2[] = new HinhTron[N];
            insertValueHCN(arr, M, sc);
            insertValueHT(arr2, N, sc);
            showHCN(arr, P, sc);
            showHT(arr2, Q, sc);
        }
    }
}
