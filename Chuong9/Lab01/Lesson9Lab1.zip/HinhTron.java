/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testproject;

public class HinhTron implements IHinhHoc
{
    double R;

    public HinhTron(double R) {
        this.R = R;
    }
    
    @Override
    public double tinhChuvi() 
    {
        return 2*R*PI;
    }
    @Override
    public double tinhDienTich() 
    {
        return R*R*PI;
    }
    @Override
    public void xuatThongTin() 
    {
        System.out.printf("Circle(r = %f): perimeter = %.3f, area = %.3f\n",R,tinhChuvi(),tinhDienTich());
    }   
}
