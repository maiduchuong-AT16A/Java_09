
package com.mycompany.testproject;

public class HinhChuNhat implements IHinhHoc
{
    double chieuDai;
    double chieuRong;
    public HinhChuNhat(double chieuDai, double chieuRong) 
    {
        this.chieuDai = chieuDai;
        this.chieuRong = chieuRong;
    }
    @Override
    public void xuatThongTin()
    {
        System.out.printf("Rectangle(%f, %f): perimeter = %.3f, area = %.3f\n",chieuDai,chieuRong,tinhChuvi(),tinhDienTich());
    }
    @Override
    public double tinhChuvi() 
    {
        return 2*(chieuDai+chieuRong);
    }
    @Override
    public double tinhDienTich() 
    {
        return (chieuDai*chieuRong);
    }
}
