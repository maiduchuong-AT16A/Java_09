/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson09.lab01;

/**
 *
 * @author Admin
 */
public interface IShape {

    double getPerimeter();

    double getArea();

    void show();
}
