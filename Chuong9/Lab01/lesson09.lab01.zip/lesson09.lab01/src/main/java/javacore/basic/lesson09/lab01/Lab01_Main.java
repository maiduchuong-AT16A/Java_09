/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson09.lab01;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Lab01_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int T = sc.nextInt();

        for (int t = 0; t < T; t++) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();

            Rectangle[] rec = new Rectangle[M];
            Circle[] cir = new Circle[N];
            for (int i = 0; i < M; i++) {
                double length = sc.nextDouble();
                double width = sc.nextDouble();
                rec[i] = new Rectangle(length, width);
            }
            for (int i = 0; i < N; i++) {
                double radius = sc.nextDouble();
                cir[i] = new Circle(radius);
            }

            int[] p = new int[P];
            int[] q = new int[Q];
            for (int i = 0; i < P; i++) {
                p[i] = sc.nextInt();
            }
            for (int i = 0; i < Q; i++) {
                q[i] = sc.nextInt();
            }

            System.out.println("Case #" + (t + 1) + ":");
            for (int i = 0; i < P; i++) {
                rec[p[i]].show();
            }
            for (int i = 0; i < Q; i++) {
                cir[q[i]].show();
            }
        }
    }
}
