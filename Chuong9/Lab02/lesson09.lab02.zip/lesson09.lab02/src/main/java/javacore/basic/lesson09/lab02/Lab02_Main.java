/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson09.lab02;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int T = sc.nextInt();

        for (int t = 0; t < T; t++) {
            int M = sc.nextInt();
            int N = sc.nextInt();

            int P = sc.nextInt();
            int Q = sc.nextInt();

            FullTimeEmployee[] fte = new FullTimeEmployee[M];
            PartTimeEmployee[] pte = new PartTimeEmployee[N];
            for (int i = 0; i < M; i++) {
                sc.nextLine();
                String name = sc.nextLine();
                int paymentPerHour = sc.nextInt();
                fte[i] = new FullTimeEmployee(name, paymentPerHour);
            }
            for (int i = 0; i < N; i++) {
                sc.nextLine();
                String name = sc.nextLine();
                int paymentPerHour = sc.nextInt();
                int workingHours = sc.nextInt();
                pte[i] = new PartTimeEmployee(name, paymentPerHour, workingHours);
            }

            int[] p = new int[P];
            int[] q = new int[Q];
            for (int i = 0; i < P; i++) {
                p[i] = sc.nextInt();
            }
            for (int i = 0; i < Q; i++) {
                q[i] = sc.nextInt();
            }

            System.out.println("Case #" + (t + 1) + ":");
            for (int i = 0; i < P; i++) {
                fte[p[i]].showInfo();
            }
            for (int i = 0; i < Q; i++) {
                pte[q[i]].showInfo();
            }
        }
    }
}
