/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package javacore.basic.lesson09.lab02;

/**
 *
 * @author Admin
 */
public class Lesson09Lab02 {

    public static void main(String[] args) {
        
    }
}
