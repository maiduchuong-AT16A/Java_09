/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lesson09.lab02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lab02_Main 
{
    static void insertPartime(PartTimeEmployee arr[], int N, Scanner sc)
    {
        String name;
        int income;
        int hours;
        for(int i = 0;i < N; i++)
        {
            sc.nextLine();
            name = sc.nextLine();
            income = sc.nextInt();
            hours = sc.nextInt();
            PartTimeEmployee pte = new PartTimeEmployee(name, income, hours);
            arr[i] = pte;
        }
        
    }
    static void insertFulltime(FullTimeEmployee arr[], int M, Scanner sc)
    {
        String name;
        int income;
        for(int i = 0;i < M; i++)
        {
            sc.nextLine();
            name = sc.nextLine();
            income = sc.nextInt();
            FullTimeEmployee fte = new FullTimeEmployee(name, income);
            arr[i] = fte;
        }
    }
    static void showPartime(PartTimeEmployee arr[], int P, Scanner sc)
    {
        byte a;
        for(int i = 0; i < P; i++)
        {
            a = sc.nextByte();
            System.out.println("Part time employee:");
            arr[a].showInfo();
        }
    }
    static void showFulltime(FullTimeEmployee arr[], int Q, Scanner sc)
    {
        byte a;
        for(int i = 0; i < Q; i++)
        {
            a = sc.nextByte();
            System.out.println("Full time employee:");
            arr[a].showInfo();
        }
    }
    public static void main(String[] args) throws FileNotFoundException
    {
        System.setIn(new FileInputStream("Input.txt"));
        Scanner sc = new Scanner(System.in);
        byte T = sc.nextByte();
        int M,N,P,Q;
        for(int t = 1; t < T; t++)
        {
            System.out.printf("Case #%d:\n",t);
            M = sc.nextInt();
            N = sc.nextInt();
            P = sc.nextInt();
            Q = sc.nextInt();
            FullTimeEmployee arr[] = new FullTimeEmployee[M];
            PartTimeEmployee arr2[] = new PartTimeEmployee[N];
            insertFulltime(arr, M, sc);
            insertPartime(arr2, N, sc);
            showFulltime(arr, P, sc);
            showPartime(arr2, Q, sc);
        }
    }
}
