/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lesson09.lab02;

/**
 *
 * @author NTHie
 */
public class Employee implements IEmployee,IShow
{
    String name;
    int paymentPerHour;

    public Employee(String name, int paymentPerHour) 
    {
        this.name = name;
        this.paymentPerHour = paymentPerHour;
    }
    @Override
    public String getName() 
    {
        return name;
    }
    @Override
    public int calculateSalary()
    {
        return paymentPerHour;
    }
    @Override
    public void showInfo() 
    {
        System.out.println("Name: " + name + ", salary per day: " + calculateSalary());
    } 
}
