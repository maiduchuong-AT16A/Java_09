/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package lesson09.lab01.mavenproject1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class Mavenproject1 {

    public static void main(String[] args) throws FileNotFoundException {
        System.setIn(new FileInputStream("input.txt"));
        
        Scanner sc = new Scanner(System.in);
                
        int testCase = sc.nextInt();
        for(int i=0;i<testCase;i++)
        {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();
            
            Rectangle[] hcn = new Rectangle[M];
            Circle[] ht = new Circle[N];
            
            for (int j=0;j<M;j++)
            {
                double cd=sc.nextDouble();
                double cr=sc.nextDouble();
                hcn[j] = new Rectangle(cd, cr);
            }
            
            for(int j=0;j<N;j++)
            {
                double r =sc.nextDouble();
                ht[j] = new Circle(r);
            }
            
            int[] vitrip = new int[P];
            for(int j=0;j<P;j++)
            {
                vitrip[j] = sc.nextInt();
            }
                    
            int[] vitriq = new int[Q];
            for(int j=0;j<Q;j++)
            {
                vitriq[j] = sc.nextInt();
            }
            
            System.out.printf("Case #%d:\n",i+1);
            for(int num:vitrip)
            {
                hcn[num].show();
            }
            for(int num:vitriq)
            {
                ht[num].show();
            }
        }
    }
}
