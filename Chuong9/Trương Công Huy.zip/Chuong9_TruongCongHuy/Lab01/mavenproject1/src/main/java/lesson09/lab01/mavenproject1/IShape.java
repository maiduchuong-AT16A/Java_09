/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lesson09.lab01.mavenproject1;

/**
 *
 * @author Huy
 */
public interface IShape {
    double getPerimeter();
    double getArea();
    void show();
}
