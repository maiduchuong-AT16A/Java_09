/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson09.lab01.mavenproject1;

/**
 *
 * @author Huy
 */
public class Circle implements IShape{
    double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double getPerimeter() {
       return  2.0*Math.PI*radius;
    }

    @Override
    public double getArea() {
        return Math.PI*radius*radius;
    }

    @Override
    public void show() {
        System.out.printf(String.format("Circle(r = %f): perimeter = %.3f, area = %.3f\n",radius,getPerimeter(),getArea()));
    }
    
    
}
