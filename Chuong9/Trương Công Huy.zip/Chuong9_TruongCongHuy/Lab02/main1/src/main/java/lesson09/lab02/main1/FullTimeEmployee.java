/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson09.lab02.main1;

/**
 *
 * @author Huy
 */
public class FullTimeEmployee extends Employee{
    
    public FullTimeEmployee(String name, int paymomentPerHour) {
        super(name, paymomentPerHour);
    }
    
    @Override
    public int calculateSalary()
    {
        return 8*paymomentPerHour;
    }
    
    @Override
    public void show()
    {
        System.out.println("Full time employee: ");
        System.out.printf(String.format("Name: %s, salary per day: %d",name,calculateSalary()));
    }
}
