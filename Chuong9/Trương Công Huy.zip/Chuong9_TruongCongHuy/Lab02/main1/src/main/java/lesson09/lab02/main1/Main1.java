/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package lesson09.lab02.main1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class Main1 {

    public static void main(String[] args) throws FileNotFoundException {
        System.setIn(new FileInputStream("input.txt"));
        Scanner sc = new Scanner(System.in);
                
        int testCase = sc.nextInt();
        for(int i=0;i<testCase;i++)
        {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();
            
            FullTimeEmployee[] pF = new FullTimeEmployee[M];
            PartTimeEmployee[] pP = new PartTimeEmployee[N];
            
            for (int j=0;j<M;j++)
            {
                sc.nextLine();
                String name = sc.nextLine();
                int paymomentPerHour = sc.nextInt();
                pF[j] = new FullTimeEmployee(name, paymomentPerHour);
            }
            
            for(int j=0;j<N;j++)
            {
                sc.nextLine();
                String name = sc.nextLine();
                int paymomentPerHour = sc.nextInt();
                int workingHours = sc.nextInt();
                pP[j] = new PartTimeEmployee(workingHours, name, paymomentPerHour);
            }
            
            int[] vitrip = new int[P];
            for(int j=0;j<P;j++)
            {
                vitrip[j] = sc.nextInt();
            }
                    
            int[] vitriq = new int[Q];
            for(int j=0;j<Q;j++)
            {
                vitriq[j] = sc.nextInt();
            }
            
            System.out.printf("Case #%d:\n",i+1);
            for(int num:vitrip)
            {
                pF[num].show();
                System.out.println("");
            }
            for(int num:vitriq)
            {
                pP[num].show();
                System.out.println("");
            }
        }
    }

    

}
