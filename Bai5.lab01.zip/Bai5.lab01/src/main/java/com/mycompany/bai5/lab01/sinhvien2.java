/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bai5.lab01;

import java.util.Scanner;

/**
 *
 * @author van
 */
public class sinhvien2 {

    String HoVaTen;
    String lop;
    double diemTB;

    void nhapThongTin() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ho va ten: ");
        HoVaTen = sc.nextLine();
        System.out.println("Lop: ");
        lop = sc.nextLine();
        System.out.println("Diem trung binh: ");
        diemTB = sc.nextDouble();
    }

    void HienThiThongTin() {
        System.out.println("=======THONG TIN SINH VIEN=======");
        System.out.println("Ho va ten: " + HoVaTen);
        System.out.println("Lop: " + lop);
        System.out.println("Diem trung binh: " + diemTB);
    }

    void XepLoaiHocLuc() {
        if (diemTB > 0 && diemTB < 5) {
            System.out.println("Hoc luc yeu");
        } else if (diemTB >= 5 && diemTB < 6.5) {
            System.out.println("Hoc luc trung binh");
        } else if (diemTB >= 6.5 && diemTB < 8) {
            System.out.println("Hoc luc kha");
        } else if (diemTB >= 8 && diemTB <= 10) {
            System.out.println("Hoc luc gioi");
        } else {
            System.out.println("Du lieu sai");
        }
    }
}
