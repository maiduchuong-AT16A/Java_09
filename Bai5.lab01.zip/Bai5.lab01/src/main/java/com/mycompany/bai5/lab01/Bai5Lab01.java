/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai5.lab01;

/**
 *
 * @author van
 */
public class Bai5Lab01 {

    public static void main(String[] args) {
       sinhvien2 Student = new sinhvien2();
       Student.nhapThongTin();
       Student.HienThiThongTin();
       Student.XepLoaiHocLuc();
       
       
    }
}
