/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Student;

import java.util.Scanner;

/**
 *
 * @author van
 */
public class Student {
     String maSinhVien;
    double diemTB;
    int namSinh;
    String lop;

    public Student(String maSinhVien, double diemTB, int namSinh, String lop) {
        this.maSinhVien = maSinhVien;
        this.diemTB = diemTB;
        this.namSinh = namSinh;
        this.lop = lop;
    }

    public Student() {
    }

    void inputInfo() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ma sinh vien: ");
        maSinhVien = sc.nextLine();
        System.out.println("Lop: ");
        lop = sc.nextLine();
        System.out.println("Nam sinh: ");
        namSinh = sc.nextInt();
        sc.nextLine();
        System.out.println("Diem trung binh: ");
        diemTB = sc.nextDouble();
    }

    void showInfo() {
        System.out.println("=====THONG TIN SINH VIEN=====");
        System.out.println("Ma sinh vien: " + maSinhVien);
        System.out.println("Lop: " + lop);
        System.out.println("Nam sinh: " + namSinh);
        System.out.println("Diem trung binh: " + diemTB);
        if (checkScholarship(diemTB) == 1) {
            System.out.println("Sinh vien dat hoc bong");
        } else {
            System.out.println("Sinh vien khong dat hoc bong");
        }
    }

    int checkScholarship(double diemTB) {
        if (diemTB >= 8.0 && diemTB <= 10) {
            return 1;
        } else {
            return 0;
        }
    }
}
