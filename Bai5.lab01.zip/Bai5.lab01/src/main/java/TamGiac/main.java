/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TamGiac;

/**
 *
 * @author van
 */
public class main {

    public static void main(String[] args) {
        TamGiac tamgiac = new TamGiac();
        tamgiac.nhapTamGiac();
        tamgiac.xacDinhTamGiac(tamgiac.a, tamgiac.b, tamgiac.c);
        tamgiac.inKetQua();
    }
}
