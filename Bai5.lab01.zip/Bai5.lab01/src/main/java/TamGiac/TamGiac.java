/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TamGiac;

import java.util.Scanner;

/**
 *
 * @author van
 */
public class TamGiac {
     double a;
    double b;
    double c;

    public TamGiac(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public TamGiac() {
    }

    void nhapTamGiac() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap do dai 3 canh: ");
        a = sc.nextDouble();
        b = sc.nextDouble();
        c = sc.nextDouble();
    }

    void xacDinhTamGiac(double a, double b, double c) {
        if (a == b && b == c) {
            System.out.println("Day la tam giac deu");
        } else if (a == b || b == c || c == a) {
            System.out.println("Day la tam giac can");
        } else if ((a * a == b * b + c * c) || (b * b == a * a + c * c) || (c * c == a * a + b * b)) {
            System.out.println("Day la tam giac vuong");
        } else {
            System.out.println("Day la tam giac thuong");
        }
    }
    
    double tinhChuVi (double a, double b, double c)
    {
        return a+b+c;
    }
    
    double tinhDienTich (double a, double b, double c)
    {
        double p = (a+b+c)/2;
        return Math.sqrt((p)*(p-a)*(p-b)*(p-c));
    }
    
    void inKetQua()
    {
        System.out.println("Chu vi tam giac: "+tinhChuVi(a, b, c));
        System.out.println("Dien tich tam giac: "+tinhDienTich(a, b, c));
    }
}
