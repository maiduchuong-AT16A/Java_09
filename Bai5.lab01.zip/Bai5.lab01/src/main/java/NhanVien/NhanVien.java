/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NhanVien;

import java.util.Scanner;

/**
 *
 * @author van
 */
public class NhanVien {
    String hoTen;
    String namSinh;
    String diaChi;
    double tienLuong;
    int gioLamViec;

    public NhanVien(String hoTen, String namSinh, String diaChi, double tienLuong, int gioLamViec) {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.diaChi = diaChi;
        this.tienLuong = tienLuong;
        this.gioLamViec = gioLamViec;
    }

    public NhanVien() {
    }

    void inputInfo() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ho va ten: ");
        hoTen = sc.nextLine();
        System.out.println("Nam sinh: ");
        namSinh = sc.nextLine();
        System.out.println("Dia chi: ");
        diaChi = sc.nextLine();
        System.out.println("Tien Luong: ");
        tienLuong = sc.nextDouble();
        System.out.println("Tong gio lam viec: ");
        gioLamViec = sc.nextInt();
    }

    void printInfo() {
        System.out.println("=====THONG TIN NHAN VIEN=====");
        System.out.println("Ho va ten: " + hoTen);
        System.out.println("Nam sinh: " + namSinh);
        System.out.println("Dia chi: " + diaChi);
        System.out.println("Tien luong: " + tienLuong);
        System.out.println("Tong gio lam viec: " + gioLamViec);
        System.out.println("Tien thuong: " + tinhThuong(gioLamViec, tienLuong));
    }

    double tinhThuong(int gioLamViec, double tienLuong) {

        if (gioLamViec < 100) {
            return 0;
        } else if (gioLamViec >= 100 && gioLamViec < 200) {
            return (tienLuong / 10);
        } else if (gioLamViec >= 200) {
            return (tienLuong / 5);
        } else {
            return 0;
        }
    }
}
