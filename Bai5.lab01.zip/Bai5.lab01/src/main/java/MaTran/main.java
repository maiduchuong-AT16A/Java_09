/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MaTran;

/**
 *
 * @author van
 */
public class main {
     public static void main(String[] args) {
         maTran arr = new maTran();
         arr.nhapMaTran();
         System.out.println("Ma tran nhap vao: ");
         arr.xuatMaTran();
         System.out.println("Ma tran xoay phai: ");
         arr.xoayPhaiMaTran();
         System.out.println("Ma tran xoay trai: ");
         arr.xoayTraiMaTran();
     }
}
