/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MaTran;

import java.util.Scanner;

/**
 *
 * @author van
 */
public class maTran {

    int soHang;
    int soCot;
    int[][] mang2chieu;

    public maTran(int soHang, int soCot, int[][] mang2chieu) {
        this.soHang = soHang;
        this.soCot = soCot;
        this.mang2chieu = new int[this.soHang][this.soCot];
    }

    public maTran() {
    }

    void nhapMaTran() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap so hang: ");
        soHang = sc.nextInt();
        System.out.println("Nhap so cot: ");
        soCot = sc.nextInt();
        System.out.println("Nhap ma tran: ");
        mang2chieu = new int[soHang][soCot];
        for (int i = 0; i < soHang; i++) {
            for (int j = 0; j < soCot; j++) {
                mang2chieu[i][j] = sc.nextInt();
            }
        }
    }

    void xuatMaTran() {
        for (int i = 0; i < soHang; i++) {
            for (int j = 0; j < soCot; j++) {
                System.out.printf("%4d ", mang2chieu[i][j]);
            }
            System.out.println("");
        }
    }

    void xoayPhaiMaTran() {
        int[][] matran2 = new int[soCot][soHang];
        for (int i = 0; i < soCot; i++) {
            for (int j = 0; j < soHang; j++) {
                matran2 [i][j] = mang2chieu [soHang-j-1][i];
                System.out.printf("%4d ", matran2[i][j]);
            }
            System.out.println("");
        }
        System.out.println("");
    }
    
    void xoayTraiMaTran()
    {
        int[][] matran3 = new int [soCot][soHang];
        for (int i = 0; i < soCot; i++) {
            for (int j = 0; j < soHang; j++) {
                matran3 [i][j] = mang2chieu [j][soCot-i-1];
                System.out.printf("%4d ", matran3[i][j]);
            }
            System.out.println("");
        }
        System.out.println("");
    }
}
