/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HinhChuNhat;

import java.util.Scanner;

/**
 *
 * @author van
 */
public class HinhChuNhat {
    double dai;
    double rong;

    public HinhChuNhat(double dai, double rong) {
        this.dai = dai;
        this.rong = rong;
    }

    public HinhChuNhat() {
    }
    
    void nhapThongTin()
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Chieu dai: ");
        dai = sc.nextDouble();
        System.out.println("Chieu rong: ");
        rong = sc.nextDouble();
    }
    
    void tinhChuVi(double dai, double rong)
    {
        System.out.println("Chu vi HCN: "+(dai+rong));
    }
    
    void tinhDienTich(double dai, double rong)
    {
        System.out.println("Dien tich HCN: "+(dai*rong));
    }
}

