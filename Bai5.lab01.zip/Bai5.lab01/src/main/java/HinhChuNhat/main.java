/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HinhChuNhat;

/**
 *
 * @author van
 */
public class main {

    public static void main(String[] args) {
        HinhChuNhat hcn = new HinhChuNhat();
        hcn.nhapThongTin();
        hcn.tinhChuVi(hcn.dai, hcn.rong);
        hcn.tinhDienTich(hcn.dai, hcn.rong);
    }
}
