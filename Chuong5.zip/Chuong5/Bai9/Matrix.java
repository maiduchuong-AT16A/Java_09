/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actvn;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class Matrix {

    int hang;
    int cot;
    int[][] arr;

    public Matrix(int hang, int cot) {
        this.hang = hang;
        this.cot = cot;
        this.arr = new int[hang][cot];
    }

    public Matrix() {
    }

    void nhapMatrix() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ma tran " + hang + "x" + cot);
        for (int i = 0; i < hang; i++) {
            for (int j = 0; j < cot; j++) {
                arr[i][j] = sc.nextInt();
            }
        }
    }

    void xoayphai90(){
        int [][]kq = new int[cot][hang];
        for(int i=0;i<cot;i++){
            for(int j=0;j<hang;j++){
                kq[i][j]=arr[hang-1-j][i];
            }
        }
        
        arr=kq;
        
        int temp = hang;
        hang= cot;
        cot=temp;
     }
    
    void xoaytrai90(){
        int [][]kq = new int[cot][hang];
        for(int i=0;i<cot;i++){
            for(int j=0;j<hang;j++){
                kq[i][j]=arr[j][cot-1-i];
            }
        }
        
        arr=kq;
        
        int temp = hang;
        hang= cot;
        cot=temp;
    }
    
    void xoay180(){
        int [][]kq = new int[hang][cot];
        for(int i=0;i<hang;i++){
            for(int j=0;j<cot;j++){
                kq[i][j]=arr[hang-1-i][cot-1-j];
            }
        }        
        arr = kq;
    }
    
    void xuatMatrix() {
        System.out.println("Ma tran " + hang + "x" + cot + " : ");
        for (int i = 0; i < hang; i++) {
            for (int j = 0; j < cot; j++) {
                System.out.print(arr[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
