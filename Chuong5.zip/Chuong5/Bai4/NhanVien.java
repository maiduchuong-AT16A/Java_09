/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actvn;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class NhanVien {

    String name;
    int year;
    String adress;
    double money;
    int time;

    public NhanVien() {

    }

    public NhanVien(String name, int year, String adress, double money, int time) {
        this.name = name;
        this.year = year;
        this.adress = adress;
        this.money = money;
        this.time = time;
    }

    void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap thong tin:");
        System.out.println("name: ");
        name = sc.nextLine();
        System.out.println("year: ");
        year = sc.nextInt();
        sc.nextLine();
        System.out.println("adress: ");
        adress = sc.nextLine();
        System.out.println("money: ");
        money = sc.nextDouble();
        System.out.println("time: ");
        time = sc.nextInt();
    }

    double solve() {
        double result;
        if (time >= 200) {
            result = money + money * (double) 20 / 100;
            return result;
        } else if (time >= 100) {
            result = money + money * (double) 10 / 100;
            return result;
        }
        return money;
    }

    void output() {
        System.out.println(name + " " + year);
        System.out.println(adress);
        System.out.println(solve() + " " + time);
    }

}
