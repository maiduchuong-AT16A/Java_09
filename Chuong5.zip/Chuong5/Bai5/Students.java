/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actvn;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class Students {

    String MSV;
    double avg;
    int namSinh;
    String lop;

    public Students() {
    }

    public Students(String MSV, double avg, int namSinh, String lop) {
        this.MSV = MSV;
        this.avg = avg;
        this.namSinh = namSinh;
        this.lop = lop;
    }

    void inputInfo() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap thong tin:");
        System.out.println("MSV: ");
        MSV = sc.nextLine();
        System.out.println("DTB: ");
        avg = sc.nextDouble();
        sc.nextLine();
        System.out.println("Nam sinh: ");
        namSinh = sc.nextInt();
        sc.nextLine();
        System.out.println("Lop: ");
        lop = sc.nextLine();

    }

    boolean checkScholarship() {
        return avg >= 8.0;
    }

    void showInfo() {
        char result = lop.charAt(0);
        if (namSinh<2002||(result != 'A' && result != 'C' && result != 'D')||MSV.length()!=8) {
            System.out.println("du lieu khong hop le");
        } else {
            System.out.println(MSV + " " + avg + " " + namSinh + " " + lop);
            if (checkScholarship()) {
                System.out.println("Dat hoc bong");
            } else {
                System.out.println("Khong dat hoc bong");
            }
        }

    }
}
