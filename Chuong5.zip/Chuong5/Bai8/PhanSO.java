/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actvn;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class PhanSO {
    private int tuSo;
    private int mauSo;

    public PhanSO() {
    }

    public PhanSO(int tuSo, int mauSo) {
        this.tuSo = tuSo;
        this.mauSo = mauSo;
    }

    public void nhapPhanSo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhap tu so: ");
        tuSo = scanner.nextInt();
        System.out.print("Nhap mau so: ");
        mauSo = scanner.nextInt();
    }

    private int timUCLN(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public void rutGon() {
        int ucln = timUCLN(tuSo, mauSo);
        tuSo /= ucln;
        mauSo /= ucln;
    }

    public void hienThiPhanSo() {
        System.out.println(tuSo + "/" + mauSo);
    }

    public void nghichDao() {
        if (tuSo != 0) {
            int temp = tuSo;
            tuSo = mauSo;
            mauSo = temp;
        } else {
            System.out.println("Khong the nghich dao phan so vi tu so bang 0.");
        }
    }
}
