/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actvn;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class Hinhchunhat {
    double dai;
    double rong;

    public Hinhchunhat(double dai, double rong) {
        this.dai = dai;
        this.rong = rong;
    }

    public Hinhchunhat() {
    }
    
    void input(){
        Scanner sc = new Scanner(System.in);
        System.out.println("nha du lieu:");
        System.out.println("chieu dai: ");
        dai = sc.nextDouble();
        System.out.println("chieu rong: ");
        rong = sc.nextDouble();
    }
    double chuVi(){
        return (dai+rong)*2.0;
    }
    double dienTich(){
        return dai*rong;
    }
    void output(){
        System.out.println("Chu vi = "+chuVi());
        System.out.println("Dien tich = "+dienTich());
    }
}
