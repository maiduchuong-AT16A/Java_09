/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.actvn;
    
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Huy
 */
public class Tamgiac {

    double a, b, c;

    public Tamgiac() {
    }

    public Tamgiac(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nha du lieu:");
        System.out.println("a = ");
        a = sc.nextDouble();
        System.out.println("b = ");
        b = sc.nextDouble();
        System.out.println("a = ");
        c = sc.nextDouble();
    }

    void kiemTra() {
        if (a == b && b == c) {
            System.out.println("Tam giac deu");
        } else if (a == b || b == c || a == c) {
            System.out.println("Tam giac can");
        } else if (a * a == b * b + c * c || b * b == a * a + c * c || c * c == a * a + b * b) {
            System.out.println("Tam giac vuong");
        } else {
            System.out.println("Tam giac thuong");
        }
    }

    double chuVi() {
        double p = a + b + c;
        return p;
    }

    double DienTich() {
        double x = chuVi() / 2.0;
        double S = Math.sqrt(x * (x - a) * (x - b) * (x - c));
        return S;
    }

    void output() {
        kiemTra();
        System.out.println("chu vi = "+chuVi());
        System.out.println("dien tich = "+DienTich());
    }
}


