
package com.mycompany.javacore.basic.lesson06;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class JavacoreBasicLesson06 
{
    static void insertValue(double arr[],short n,Scanner sc)
    {
        for(int i = 0; i < n; i++)
        {
            arr[i] = sc.nextDouble();
        }
    }
    public static void main(String[] args) throws FileNotFoundException
    {
        System.setIn(new FileInputStream("Input.txt"));
        Scanner sc = new Scanner(System.in);
        byte T = sc.nextByte();
        short n;
        int k;
        String str1,str2;
        for(byte t = 1; t <= T; t++)
        {
            System.out.println("Case #" + t + ":");
            n = sc.nextShort();
            double arr[] = new double[n];
            insertValue(arr, n, sc);
            sc.nextLine();
            str1 = sc.nextLine();
            str2 = sc.nextLine();
            k = sc.nextInt();
            System.out.printf("Sum: %.2f\n",Practice.getSum(arr));
            System.out.printf("Min: %.1f\n",Practice.getMin(arr));
            System.out.printf("Max: %.1f\n",Practice.getMax(arr));
            System.out.println("To upper: " + Practice.toUpper(str1));
            System.out.println("To lower: " + Practice.toLower(str2));
            System.out.println("To upper first char: " + Practice.toUpperFirstchar(str1) + " - " + Practice.toUpperFirstchar(str2));
            System.out.printf("Fibonacci(%d): %d",k,Practice.getFibonacci(k));
        }
    }
}
