
package com.mycompany.javacore.basic.lesson06;

public class Practice 
{
    public static final double getSum(double ...x)
    {
        double sum = 0;
        int n = x.length;
        for(int i = 0; i < n; i++)
        {
            sum += x[i];
        }
        return sum;
    }
    public static final double getMin(double ...x)
    {
        double min = x[0];
        for(double a : x)
        {
            if(a < min)
            {
                min = a;
            }
        }
        return min;
    }
    public static final double getMax(double ...x)
    {
        double max = x[0];
        for(double a : x)
        {
            if(a > max)
            {
                max = a;
            }
        }
        return max;
    }
    public static String toUpper(String str)
    {
        int n = str.length();
        char[] charArr = new char[n];
        for(int i = 0; i < n; i++)
        {
            charArr[i] = str.charAt(i);
        }
        for(int i = 0; i < n; i++)
        {
            if(charArr[i] >= 'a' && charArr[i] <= 'z')
            {
                charArr[i] = (char)(charArr[i] - 32);
            }
        }
        str = String.valueOf(charArr);
        return str;
    }
    public static String toLower(String str)
    {
        int n = str.length();
        char[] charArr = new char[n];
        for(int i = 0; i < n; i++)
        {
            charArr[i] = str.charAt(i);
        }
        for(int i = 0; i < n; i++)
        {
            if(charArr[i] >= 'A' && charArr[i] <= 'Z')
            {
                charArr[i] = (char)(charArr[i] + 32);
            }
        }
        str = String.valueOf(charArr);
        return str;
    }
    public static String toUpperFirstchar(String str)
    {
        String[] words = str.split(" ");
        int n = words.length;
        char firstChar;
        char upperFirstchar;
        for(int i = 0; i < n; i++)
        {
            firstChar = words[i].charAt(0);
            upperFirstchar = String.valueOf(firstChar).toUpperCase().charAt(0);
            words[i] = upperFirstchar + words[i].substring(1);
        }
        String res = String.join(" ",words);
        return res;
    }
    public static int getFibonacci(int pos)
    {
        if(pos == 1 || pos == 2)
        {
            return 1;
        }
        return getFibonacci(pos-1) + getFibonacci(pos-2);
    }
}
