/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.Java to edit this template
 */
package practice;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class solution {

    static Scanner sc = new Scanner(System.in);

    public static void nhap(Java jv) {

    }

    public static void in(Java jv) {

    }

    public static void main(String[] args) {

        int testcase = sc.nextInt();
        Java[] jv = new Java[testcase];

        for (int i = 0; i < testcase; i++) {
            int k;
            jv[i] = new Java();

            jv[i].setSize(sc.nextInt());

            jv[i].kichCo(jv[i].getSize());

            jv[i].input(sc);
            sc.nextLine();

            jv[i].setStr1(sc.nextLine());

            jv[i].setStr2(sc.nextLine());

            k = sc.nextInt();
            System.out.println("==============");
            System.out.printf("Case #%d:\n",i+1);
            System.out.printf("Sum: %.2f\n",jv[i].getSum());
            System.out.printf("Min: %.1f\n",jv[i].getMin());
            System.out.printf("Max: %.1f\n",jv[i].getMax());
            System.out.printf("To upper: %s\n",jv[i].toUpper(jv[i].getStr1()));
            System.out.printf("To lower: %s\n",jv[i].toLower(jv[i].getStr2()));
            System.out.printf("To upper first char: %s - %s\n",jv[i].toUpperFirstChar(jv[i].getStr1()),jv[i].toUpperFirstChar(jv[i].getStr2()));
            System.out.printf("Fibonacci(%d): %d\n",k,(int)jv[i].getFibo(k));
            
           

        }
    }
}
