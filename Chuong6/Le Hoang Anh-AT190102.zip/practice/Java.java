/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.Java to edit this template
 */
package practice;

import java.util.Arrays;
import java.util.Objects;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Java {
    private double[] x;
    private String str1;
    private String str2;
    
    private int size;
    

    

    
//    static Scanner sc = new Scanner(System.in);

    public double[] getX() {
        return x;
    }

    public void setX(double[] x) {
        this.x = x;
    }
    
    

    public void kichCo(int kichco) {
        x = new double[kichco];
    }
    public void input(Scanner sc) {
        for(int i = 0;i<x.length;i++) {
            x[i] = sc.nextDouble();
        }       
    }
    

    public final double getSum() {
        double s = 0;
        for (int i = 0; i < x.length; i++) {
            s = s + x[i];

        }
        return s;
    }

    public final double getMin() {
        double min = x[0];
        for (int i = 0; i < x.length; i++) {
            if (min > x[i]) {
                min = x[i];
            }
        }
        return min;

    }

    public final double getMax() {
        double max = x[0];
        for (int i = 0; i < x.length; i++) {
            if (max < x[i]) {
                max = x[i];
            }
        }
        return max;

    }


    public static String toUpper(String str) {
        String kq = "";
        char c;
        for (int i = 0; i < str.length(); i++) {
            c = str.charAt(i);
            if (c >= 'a' && c <= 'z') {
                kq = kq + (char) (c - 32);
            } else {
                kq = kq + (char) c;
            }
        }
        return kq;
    }

    public static String toLower(String str) {
        String kq = "";
        char c;

        for (int i = 0; i < str.length(); i++) {
            c = str.charAt(i);
            if (c >= 'A' && c <= 'Z') {
                kq += (char) (c + 32);
            } else {
                kq += (char)(c);
            }

        }
        return kq;
    }

    public static String toUpperFirstChar(String str) {
        String[] word = str.split(" ");
        for (int i = 0;i<word.length;i++) {
            char firstChar = word[i].charAt(0);
            String upperFirstChar = String.valueOf(firstChar).toUpperCase();
            word[i] = upperFirstChar + word[i].substring(1).toLowerCase();
        }
        String result = String.join(" ", word);
        return result;

    }

    public static double fibo(double n) {
        if (n == 1 || n == 2) {
            return 1.0;
        }
        return fibo(n - 1) + fibo(n - 2);
    }

    public double getFibo(int position) {

        return fibo(x[position]);

    }

    public String getStr1() {
        return str1;
        
    }

    public void setStr1(String str1) {
        this.str1 = str1;
    }

    public String getStr2() {
        return str2;
    }

    public void setStr2(String str2) {
        this.str2 = str2;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    
   
}
