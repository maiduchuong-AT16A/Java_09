/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package javacore.basic.lesson06;

/**
 *
 * @author Admin
 */
public class Lesson06 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
