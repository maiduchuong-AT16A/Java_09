package luyenTap;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Tien
 */
public class TamGiac {
    double a,b,c;
    
    public TamGiac(){}
    
    public TamGiac(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    void nhap3Canh()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap do dai 3 canh");
        System.out.println("a:");
        a = sc.nextDouble();
        System.out.println("b:");
        b = sc.nextDouble();
        System.out.println("c:");
        c = sc.nextDouble();
    }
    
    double chuVi()
    {
        return(a+b+c);
    }
    
    double dienTich()
    {
        double p=chuVi()/2;
        double s = Math.sqrt(p*(p-a)*(p-b)*(p-c));
        return s;
    }
    
    void loaiTgiac()
    {
        if (a==b && b==c)
            System.out.println("Tam giac deu");
        else if (a==b||b==c||c==a)
            System.out.println("Tam giac can");
        else if (a*a==(b*b+c*c) || (a*a+b*b)==c*c || (a*a+c*c)==b*b)
            System.out.println("Tam giac vuong");
        else
            System.out.println("Tam giac thuong");
    }
}
