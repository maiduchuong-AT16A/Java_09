package luyenTap;


import java.util.Scanner;

public class HinhChuNhat {
    double dai, rong;
    
    public HinhChuNhat(){}

    public HinhChuNhat(double dai, double rong) {
        this.dai = dai;
        this.rong = rong;
    }

    public HinhChuNhat(double canh) {
        this.dai = canh;
        this.rong = canh;
    }
    
    void nhap2Canh()
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap dai: ");
        dai =sc.nextDouble();
        System.out.print("Nhap rong: ");
        rong = sc.nextDouble();
    }
    
    double chuVi()
    {
        return (2*dai+2*rong);
    }
    
    double dienTich()
    {
        return(dai*rong);
    }
}
