package luyenTap;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Nhan vien\t2.Student\n3.Hinh chu nhat\t4.Tam giac\n5.Phan so\t6.Ma tran\n0.Thoat");
        byte ch=1;
        
        do{
            System.out.print("Nhap lua chon: ");
            ch = sc.nextByte();
            switch (ch) {
                case 1:
                    NhanVien nv = new NhanVien();
                    nv.inputInfo();
                    nv.printInfo();
                    System.out.println(">> Tien thuong: " + nv.tinhThuong());
                    break;
                case 2:
                    Student st = new Student();
                    st.inputInfo();
                    st.printInfo();
                    if (st.checkScholarship()==true)
                        System.out.println("Co hoc bong");
                    else
                        System.out.println("Khong co hoc bong");            
                    break;
                case 3:
                    HinhChuNhat hcn = new HinhChuNhat();
                    hcn.nhap2Canh();
                    System.out.println("Chu vi: "+hcn.chuVi());
                    System.out.println("Dien tich: "+hcn.dienTich());
                    break;
                case 4:
                    TamGiac tg = new TamGiac();
                    tg.nhap3Canh();
                    tg.loaiTgiac();
                    System.out.println("Chu vi: "+tg.chuVi());
                    System.out.println("Dien tich: "+tg.dienTich());
                    break;
                case 5:
                    PhanSo ps = new PhanSo();
                    ps.nhapPhanSo();
                    ps.showPhanSo();
                    ps.rutGon();
                    ps.showPhanSo();
                    ps.nghichDaoPs();
                    ps.showPhanSo();
                    break;
                case 6:
                    MaTran mt = new MaTran();
                    mt.nhapMaTran();
                    mt.quay180();
                    mt.xuatMaTran();
                    mt.quayPhai90();
                    mt.xuatMaTran();
                    mt.quayTrai90();
                    mt.xuatMaTran();
                    break;
                default:
                    break;
            }
        } while (ch!=0);
    }

}
