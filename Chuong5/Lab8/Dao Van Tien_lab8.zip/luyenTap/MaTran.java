package luyenTap;


import java.awt.BorderLayout;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Tien
 */
public class MaTran {
    static Scanner sc = new Scanner(System.in);
    short hang, cot;
    int[][] arr;

    public MaTran() {
    }

    public MaTran(short hang, short cot, int[][] arr) {
        this.hang = hang;
        this.cot = cot;
        this.arr = new int[hang][cot];
        this.arr = arr;
    }
    
    void nhapMaTran()
    {
        System.out.print("Nhap so hang, so cot: ");
        hang = sc.nextShort();
        cot  = sc.nextShort();
        arr = new int[hang][cot];
        System.out.println("Nhap ma tran: ");
        for (short i=0; i<hang; i++)
        {
            for (short j=0; j<cot; j++)
                arr[i][j] = sc.nextInt();
        }
    }
    
    void xuatMaTran()
    {
        for (short i=0; i<hang; i++)
        {
            for (int x: arr[i])
                System.out.printf("%3d ", x);
            System.out.println("");
        }
        System.out.println("==========");
    }
    
    void quayPhai90(){
        int[][] kq = new int[cot][hang];
        for (short i=0; i<cot; i++)
        {
            for (short j=0; j<hang; j++)
                kq[i][j]=arr[hang-1-j][i];
        }
        
        // Thiết lập lại giá trị của "hang" - "cot" sau khi quay
        short tmp=hang;
        hang=cot;
        cot=tmp;
        
        //arr = new int[hang][cot];
        arr = kq;
        System.out.println("Quay phai 90 do.");
    }
    
    void quayTrai90()
    {
        int[][] kq = new int[cot][hang];
        for (short i=0; i<cot; i++)
        {
            for (short j=0; j<hang; j++)
                kq[i][j]=arr[j][cot-1-i];
        }
        
        // Thiết lập lại giá trị của "hang" - "cot" sau khi quay
        short tmp=hang;
        hang=cot;
        cot=tmp;
        
        arr = new int[hang][cot];
        arr = kq;
        
        System.out.println("Quay trai 90 do.");
    }
    
    void quay180(){
        int[][] kq = new int[hang][cot];
        for (short i=0; i<hang; i++)
        {
            for (short j=0; j<cot; j++)
            {
                kq[i][j] = arr[hang-1-i][cot-1-j];
            }
        }
        arr=kq;
        System.out.println("Quay 180 do.");
    }
    
}
