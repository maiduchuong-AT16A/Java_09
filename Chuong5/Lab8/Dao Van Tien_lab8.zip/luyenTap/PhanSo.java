package luyenTap;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Tien
 */
public class PhanSo{
    int tu, mau;

    public PhanSo() {
    }

    public PhanSo(int tu, int mau) {
        this.tu = tu;
        this.mau = mau;
    }
    
    void nhapPhanSo(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap tu, mau: ");
        tu = sc.nextInt();
        mau = sc.nextInt();
    }
    
    int ucln(int a, int b)
    {
        int r=-1;
        while (r!=0)
        {
            r=a%b;
            if (r==0)
                break;
            a=b;
            b=r;
        }
        return b;
    }
    
    void rutGon()
    {
        int n = ucln(tu, mau);
        tu/=n;
        mau/=n;
    }
    
    void showPhanSo()
    {
        System.out.println(tu+"/"+mau);
    }
    
    void nghichDaoPs()
    {
        int tmp=tu;
        tu=mau;
        mau=tmp;
    }
    
}
