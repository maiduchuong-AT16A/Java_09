package luyenTap;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Tien
 */
public class Student {
    String maSnhVien;
    float diemTB;
    short namSinh;
    String lop;
    
    public Student(){}

    public Student(String maSnhVien, float diemTB, short namSinh, String lop) {
        this.maSnhVien = maSnhVien;
        this.diemTB = diemTB;
        this.namSinh = namSinh;
        this.lop = lop;
    }
    
    
    public void inputInfo()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("     Nhap thong tin nhan vien");
        System.out.print("Nhap ma sinh vien: ");
        maSnhVien = sc.nextLine();
        System.out.print("Nhap diem TBinh  : ");
        diemTB = sc.nextFloat();
        System.out.print("Nhap nam sinh    : ");
        namSinh = sc.nextShort();
        sc.nextLine();
        System.out.print("Nhap lop         : ");
        lop = sc.nextLine();
    }
    
    public void printInfo()
    {
        System.out.println(">> Ma sinh vien: "+maSnhVien);
        System.out.printf(">> Diem TBinh  : %.01f\n",diemTB);
        System.out.println(">> Nam sinh    : "+namSinh); 
        System.out.println(">> Lop         : "+lop);
    }
    
    boolean checkScholarship()
    {
        if (diemTB>=8)
            return true;
        return false;
    }
}
