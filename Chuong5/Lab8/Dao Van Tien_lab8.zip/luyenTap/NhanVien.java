package luyenTap;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Tien
 */
public class NhanVien {
    String HoVaTen;
    short namSinh;
    String diaChi;
    double luong;
    int tongGioLam;
    
    public NhanVien(){}

    public NhanVien(String HoVaTen, short namSinh, String diaChi, double luong, int tongGioLam) {
        this.HoVaTen = HoVaTen;
        this.namSinh = namSinh;
        this.diaChi = diaChi;
        this.luong = luong;
        this.tongGioLam = tongGioLam;
    }
    
    
    public void inputInfo()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("     Nhap thong tin nhan vien");
        System.out.print("Nhap ho va ten   : ");
        HoVaTen = sc.nextLine();
        System.out.print("Nhap nam sinh    : ");
        namSinh = sc.nextShort();
        sc.nextLine();
        System.out.print("Nhap dia chi     : ");
        diaChi = sc.nextLine();
        System.out.print("Nhap tien luong  : ");
        luong = sc.nextDouble();
        System.out.print("Nhap tong gio lam: ");
        tongGioLam = sc.nextInt();
    }
    
    public void printInfo()
    {
        System.out.println(">> Ho va ten   : "+HoVaTen);
        System.out.println(">> Nam sinh    : "+namSinh);
        System.out.println(">> Dia chi     : "+diaChi); 
        System.out.println(">> Tien luong  : "+luong); 
        System.out.println(">> Tong gio lam: "+tongGioLam);
    }
    
    double tinhThuong()
    {
        if (tongGioLam>=200)
            return luong*0.2;
        else if (tongGioLam>=100)
            return luong*0.1;
        return 0;
    }
}
