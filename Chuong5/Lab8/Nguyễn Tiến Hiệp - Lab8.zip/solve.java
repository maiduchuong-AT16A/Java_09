
package com.mycompany.oop;

import java.util.Scanner;

public class solve 
{
    int a;
    int b;
    public solve()
    {
        
    }
    public solve(int a, int b) 
    {
        this.a = a;
        this.b = b;
    }
    void input()
    {
        Scanner sc = new Scanner(System.in);
        a = sc.nextInt();
        b = sc.nextInt();
    }
    void rutGon()
    {
        int r;
        int a1 = a;
        int b1 = b;
        while(b1 != 0)
        {
            r = a1 % b1;
            a1 = b1;
            b1 = r;
        }
        a = a/a1;
        b = b/a1;
        System.out.printf("%f\n",(double)a/b);
    }
    void nghichDao()
    {
        double res = (double)a/b;
        System.out.printf("%f",(double)1/res);
    }
}
