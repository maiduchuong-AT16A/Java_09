
package com.mycompany.oop;

import java.util.Scanner;

public class OOP 
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("===== Nhap phan so =====");
        solve phanso = new solve();
        phanso.input();
        phanso.rutGon();
        phanso.nghichDao();
    }
}
