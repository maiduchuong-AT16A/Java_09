/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject5;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Fraction {

    long a;
    long b;

    public Fraction(long a, long b) {
        this.a = a;
        this.b = b;
    }

    public Fraction() {

    }

    void inputInfo() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap du lieu: ");
        System.out.println("Nhap tu so cua phan so: ");
        a = sc.nextLong();
        System.out.println("Nhap mau so cua phan so: ");
        b = sc.nextLong();
    }

    void showInfo() {
        if (b != 0) {
            System.out.println("Phan so la: " + a + "/" + b);
        } else {
            System.out.println("Khong ton tai phan so");
        }
    }

    void rutGon() {
        long c = a;
        long d = b;
        long r;
        
        while (d != 0) {
            r = c % d;
            c = d;
            d = r;
        }
        
        long e = a / c;
        long f = b / c;
        
        System.out.println("Phan so rut gon la: " + e + "/" + f);
    }

    void nghichDao() {
        long c = a;
        long d = b;
        long r;
        
        while (d != 0) {
            r = c % d;
            c = d;
            d = r;
        }
        
        long e = a / c;
        long f = b / c;
        
        System.out.println("Phan so nghich dao la: " + b + "/" + a + " = " + f + "/" + e);
    }
}
