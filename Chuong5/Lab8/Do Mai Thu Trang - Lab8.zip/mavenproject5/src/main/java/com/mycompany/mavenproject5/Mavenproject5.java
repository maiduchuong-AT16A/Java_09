/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject5;

/**
 *
 * @author Admin
 */

import java.util.Scanner;

public class Mavenproject5 {

    public static void main(String[] args) {
        
    }
}
