/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PhanSo;

/**
 *
 * @author van
 */
public class main {
    public static void main(String[] args) {
       PhanSo phanso = new PhanSo();
       phanso.nhapPhanSo();
       phanso.hienThiPhanSo(phanso.tu, phanso.mau);
       phanso.rutGonPhanSo(phanso.tu, phanso.mau, phanso.tim_ucln(phanso.tu, phanso.mau));
       phanso.nghichDaoPhanSo(phanso.tu, phanso.mau);
    }
}
