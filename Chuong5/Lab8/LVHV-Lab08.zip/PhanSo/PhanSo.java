/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PhanSo;

import java.util.Scanner;

/**
 *
 * @author van
 */
public class PhanSo {
    int tu;
    int mau;

    public PhanSo(int tu, int mau) {
        this.tu = tu;
        this.mau = mau;
    }

    public PhanSo() {
    }

    void nhapPhanSo() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap tu so: ");
        tu = sc.nextInt();
        System.out.println("Nhap mau so: ");
        mau = sc.nextInt();
    }

    void hienThiPhanSo(int tu, int mau) {
        System.out.printf("Phan so nhap vao: %d/%d\n", tu, mau);
    }

    int tim_ucln(int a, int b) {
        int r;
        int temp;
        if (b > a) {
            temp = b;
            b = a;
            a = temp;
        }

        while (b != 0) {
            r = a % b;
            a = b;
            b = r;
        }
        return a;
    }

    void rutGonPhanSo(int tu, int mau, int ucln) {
        int a = tu / ucln;
        int b = mau / ucln;
        System.out.printf("Phan so rut gon: %d/%d\n", a, b);
    }

    void nghichDaoPhanSo(int a, int b) {
        int temp;
        temp = b;
        b = a;
        a = temp;
        System.out.printf("Phan so nghich dao: %d/%d\n", a, b);
    }
}
