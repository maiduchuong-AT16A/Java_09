/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.phanso;

/**
 *
 * @author Admin
 */
public class NewClass {
    public static void main(String[] args) {
        PhanSo phanso = new PhanSo();
        phanso.input();
        phanso.rutGon();
        phanso.hienThiPhanSo();
        phanso.nghichDaoPhanSo();
        phanso.hienThiPhanSoNghichDao();
    }
}
