/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class TamGiac {

    double a, b, c;

    public TamGiac() {
    }

    public TamGiac(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    void input() {
        Scanner sc = new Scanner(System.in);
        a = sc.nextDouble();
        b = sc.nextDouble();
        c = sc.nextDouble();
    }

    String check() {

        if (a == b && c == b) {
            return "Tam giac deu";
        } else if (a == b || a == c || a == c) {
            return "Tam giac can";
        } else if (a * a == b * b + c * c || a * a + b * b == c * c || b * b == a * a + c * c) {
            return "Tam giac vuong";
        } else {
            return "Tam giac thuong";
        }
    }

    double ChuVi() {
        return a + b + c;
    }

    double DienTich() {
        double p = ChuVi() / 2.0;
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));
    }

    void output() {
        if ((a >= b + c) || (a + b <= c) || (a + c <= b)) {
            System.out.println("Du kien khong hop le");
        } else {
            System.out.printf(String.format("Tam giac(%.2f, %.2f, %.2f) la: %s. Chu vi: %.2f, Dien tich: %.2f", a, b, c, check(), ChuVi(), DienTich()));
        }
    }
}
