/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class HinHChuNhat {
    double cd,cr;

    public HinHChuNhat() {
    }

    public HinHChuNhat(double cd, double cr) {
        this.cd = cd;
        this.cr = cr;
    }
    
    void input()
    {
        Scanner sc= new Scanner(System.in);
        
        cd=sc.nextDouble();
        cr=sc.nextDouble();
    }
    
    double ChuVi()
    {
        return (cd+cr)*2.0;
    }
    
    double DienTich(){
        return cd*cr;
    }
    
    void output()
    {
        System.out.printf(String.format("HCN(%.2f, %.2f):\nChu vi: %.2f, Dien tich: %.2f", cd,cr, ChuVi(), DienTich()));
    }

}
