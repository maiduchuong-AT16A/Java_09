/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
//	Các thuộc tính
//-	Mã sinh viên: 8 ký tự
//-	Điểm trung bình: 0.0 -> 10.0
//-	Năm sinh: >= 2002
//-	Lớp: Phải bắt đầu bằng ‘A’, ‘C’ hoặc D
//	Hàm khởi tạo (Constructor):
//-	Không tham số
//-	Đầy đủ tham số
//	Các phương thức:
//-	phương thức inputInfo(), nhập thông tin Student từ bàn phím
//-	phương thức showInfo(), hiển thị tất cả thông tin của Student
//-	phương thức checkScholarship(), kiểm tra xem Student có đạt học bổng hay không. Nếu có trả về true, ngược lại trả về false (điểm TB >= 8.0 sẽ đạt học bổng)
public class Student {

    String MSV;
    double avg;
    int NamSinh;
    String Lop;

    public Student() {
    }

    public Student(String MSV, double avg, int NamSinh, String Lop) {
        this.MSV = MSV;
        this.avg = avg;
        this.NamSinh = NamSinh;
        this.Lop = Lop;
    }

    void inputInfo() {
        Scanner sc = new Scanner(System.in);
        MSV = sc.nextLine();
        avg = sc.nextDouble();
        sc.nextLine();
        NamSinh = sc.nextInt();
        sc.nextLine();
        Lop = sc.nextLine();
    }

    String checkScholarship() {
        if(avg>=8.0)
        {
            return "Dat hoc bong";
        }else{
            return "Khong dat hoc bong";
        }
    }

    void showInfo() {
        char a = Lop.charAt(0);
        if (MSV.length() != 8 || NamSinh < 2002 || (a != 'A' && a != 'C' && a != 'D')) {
            System.out.println("Du lieu khong hop le");
        }
        else{
            System.out.println("Ma sinh vien: "+MSV);
            System.out.printf("Diem trung binh: %.2f\n", avg);
            System.out.printf("Nam sinh: %d\n", NamSinh);
            System.out.println("Lop: "+Lop);
            System.out.println(checkScholarship());
        }
    }

}
