/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class Matrix {
    int r,c;
    int[][] arr;
    
    public Matrix() {
    }

    public Matrix(int r, int c) {
        this.r = r;
        this.c = c;
        this.arr = new int[r][c];
    }
    
    void input(){
        Scanner sc=new Scanner(System.in);
        for(int i = 0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    
    void xoayphai90()
    {
        int[][] kq = new int[c][r];
        for (int i=0;i<c;i++)
        {
            for(int j=0;j<r;j++){
                kq[i][j]=arr[r-1-j][i];
            }
        }
        arr=kq;
        int temp = r;
        r=c;
        c=temp;
    }
    
    void xoaytrai90()
    {
        int[][] kq = new int[c][r];
        for (int i=0;i<c;i++)
        {
            for(int j=0;j<r;j++){
                kq[i][j]=arr[j][c-1-i];
            }
        }
        arr=kq;
        int temp = r;
        r=c;
        c=temp;
    }
    
    void xoay180()
    {
        int[][] kq = new int[r][c];
        for (int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++){
                kq[i][j]=arr[r-i-1][c-1-j];
            }
        }
        arr=kq;
    }
    
    void output()
    {
        for(int i = 0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                System.out.printf("%5d",arr[i][j]);
            }
            System.out.println("");
        }
    }
}
