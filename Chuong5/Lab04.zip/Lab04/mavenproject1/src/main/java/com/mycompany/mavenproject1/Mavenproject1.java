/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author Huy
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        // NhanVien nv1 = new NhanVien();
        //Student std1 = new Student();
        //TamGiac tg1 = new TamGiac();
        //HinHChuNhat hcn1= new HinHChuNhat();
        
        //hcn1.input();
        //hcn1.output();
        //tg1.input();
        //tg1.output();
        //nv1.inputInfo();
        //std1.inputInfo();
        //nv1.printInfo();
        //std1.showInfo();
        /*PhanSo ps1 = new PhanSo();
        ps1.input();

        ps1.rutGonPhanSo();
        ps1.hienThiPhanSo();

        ps1.nghichDaoPhanSo();
        ps1.hienThiPhanSo();/*/
        
        Matrix mt1 = new Matrix(3,2);
        mt1.input();
        mt1.xoayphai90();
        mt1.output();
        System.out.println("");
        mt1.xoay180();
        mt1.output();
        System.out.println("");
        mt1.xoaytrai90();
        mt1.output();
    }
}
