/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.Scanner;

/**
 *
 * @author Huy
 */
public class PhanSo {

    int tuSo, mauSo;

    public PhanSo(int tuSo, int mauSo) {
        this.tuSo = tuSo;
        this.mauSo = mauSo;
    }

    public PhanSo() {
    }

    void input() {
        Scanner sc = new Scanner(System.in);
        tuSo = sc.nextInt();
        mauSo = sc.nextInt();
    }

    void rutGonPhanSo() {
        int gcd = ucln(this.tuSo, this.mauSo);
        this.tuSo /= gcd;
        this.mauSo /= gcd;
    }

    public void hienThiPhanSo() {
        if (this.mauSo == 1) {
            System.out.println(this.tuSo);
        } else {
            System.out.println(this.tuSo + "/" + this.mauSo);
        }
    }

    public void nghichDaoPhanSo() {
        if (this.tuSo == 0) {
            System.out.println("loi phan so");
        }
        int temp = this.tuSo;
        this.tuSo = this.mauSo;
        this.mauSo = temp;
    }

    int ucln(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return Math.abs(a);
    }
}
