/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai9;

/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {
        MaTran mt = new MaTran(3, 3);
        mt.inputInfo();
        mt.xoayPhai90();
        mt.xoayTrai90();
        mt.xoay180();
        
    }
}
