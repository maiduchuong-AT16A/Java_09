/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai6;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class TamGiac {

    private double a;
    private double b;
    private double c;
    static Scanner sc = new Scanner(System.in);

    public TamGiac(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public TamGiac() {
    }

    public void nhapDoDai() {
        System.out.println("Nhap do dai canh a: ");
        this.a = sc.nextDouble();
        System.out.println("Nhap do dai canh b: ");
        this.b = sc.nextDouble();
        System.out.println("Nhap do dai canh c: ");
        this.c = sc.nextDouble();
    }

    public void kiemTraTamGiac() {
        if (a + b > c && b + c > a && a + c > b) {
            if (a == b && b == c) {
                System.out.println("Tam giac deu");
            } else if (a == b || b == c || a == c) {
                System.out.println("Tam giac can");
            } else if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a) {
                System.out.println("Tam giac vuong");
            } else {
                System.out.println("Tam giac thuong");
            }

        }

    }

    public double chuVi() {
        if (a + b > c && b + c > a && a + c > b) {
            double chuvi = a + b + c;
            return chuvi;
        }
        return 0;
    }
    public double dienTich() {
        if (a + b > c && b + c > a && a + c > b) {
            double p = chuVi()/2;
            double dienTich = Math.sqrt(p*(p-a)*(p-b)*(p-c));
            return dienTich;
        }
        return 0;
    }

}
