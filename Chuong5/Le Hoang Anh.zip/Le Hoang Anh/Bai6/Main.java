/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai6;

/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {
        TamGiac tg = new TamGiac();
        tg.nhapDoDai();
        tg.kiemTraTamGiac();
        System.out.println("Chu vi cua tam giac: " + tg.chuVi());
        System.out.println("Dien tich cua tam giac: " + tg.dienTich());
    }
         
}
