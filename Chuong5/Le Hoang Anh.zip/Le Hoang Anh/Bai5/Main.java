/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai5;

/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {
        Student st = new Student();
        st.inputInfo();
        st.showInfo();
        if(st.checkScholarship() == true) {
            System.out.println("Sinh vien co hoc bong");
        }else {
            System.out.println("Sinh vien khong co hoc bong");
        }
        
    }
}
