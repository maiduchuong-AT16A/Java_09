/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai5;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Student {
    private String maSv;
    private double diemTB;
    private int namSinh;
    private String lop;
    static Scanner sc = new Scanner(System.in);

    public Student(String maSv, double diemTB, int namSinh, String lop) {
        this.maSv = maSv;
        this.diemTB = diemTB;
        this.namSinh = namSinh;
        this.lop = lop;
    }

    public Student() {
    }
    public void inputInfo() {
        System.out.println("Nhap ma sinh vien: ");
        this.maSv = sc.nextLine();
        System.out.println("Nhap diem trung binh: ");
        this.diemTB = sc.nextDouble();
        System.out.println("Nhap nam sinh: ");
        this.namSinh = sc.nextInt();
        sc.nextLine();
        System.out.println("Nhap lop: ");
        this.lop = sc.nextLine();
        
    }
    public void showInfo() {
        System.out.println("===================");
        System.out.println("Ma sinh vien: " + this.maSv);
        System.out.println("Diem trung binh: " + this.diemTB);
        System.out.println("Nam sinh: " + this.namSinh);
        System.out.println("Lop: " + this.lop);
    }
    public boolean checkScholarship() {
        boolean check = true;
        if(diemTB>= 8.0 ) {
            check = true;
        }else {
            check = false;
        }
        return check;
    }
    
    

    
    
            
    
}
