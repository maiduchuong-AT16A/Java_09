
package com.mycompany.oop;

import java.util.Scanner;

public class OOP 
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("===== Nhap ma tran =====");
        int m = sc.nextInt();
        int n = sc.nextInt();
        solve matrix = new solve(m,n);
        matrix.output();
        matrix.rotateRight();
        matrix.rotate180();
        matrix.rotateLeft();
    }
}
