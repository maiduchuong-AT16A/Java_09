
package com.mycompany.oop;

import java.util.Scanner;

public class solve 
{
    Scanner sc = new Scanner(System.in);
    int m;
    int n;
    int arr[][];
    public solve()
    {
        
    }
    public solve(int m, int n) 
    {
        this.m = m;
        this.n = n;
        this.arr = new int[m][n];
        for(int i = 0; i < m; i++)
        {
            for(int j = 0; j < n; j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    void input()
    {
        m = sc.nextInt();
        n = sc.nextInt();
        this.arr = new int[m][n];
        for(int i = 0; i < m; i++)
        {
            for(int j = 0; j < n; j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    void output()
    {
        for(int i = 0; i < m; i++)
        {
            for(int j = 0; j < n; j++)
            {
                System.out.printf("%4d",arr[i][j]);
            }
            System.out.println("");
        }
        System.out.println("");
    }
    void rotateLeft()
    {
        for(int i = n-1; i >= 0; i--)
        {
            for(int j = 0; j < m; j++)
            {
                System.out.printf("%4d",arr[j][i]);
            }
            System.out.println("");
        }
        System.out.println("");
    }
    void rotateRight()
    {
        for(int i = 0; i < n; i++)
        {
            for(int j = m-1; j >= 0; j--)
            {
                System.out.printf("%4d",arr[j][i]);
            }
            System.out.println("");
        }
        System.out.println("");
    }
    void rotate180()
    {
        for(int i = m-1; i >= 0; i--)
        {
            for(int j = n-1; j >= 0; j--)
            {
                System.out.printf("%4d",arr[i][j]);
            }
            System.out.println("");
        }
        System.out.println("");
    }
}
