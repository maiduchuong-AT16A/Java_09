/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject6;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Matrix {

    int row;
    int column;
    int[][] a;

    public Matrix(int row, int column) {
        this.row = row;
        this.column = column;
        this.a = new int[row][column];
    }

    public Matrix() {

    }

    void inputInfo() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap du lieu: ");
        System.out.println("Nhap so hang cua ma tran: ");
        row = sc.nextInt();
        System.out.println("Nhap so cot cua ma tran: ");
        column = sc.nextInt();
        a = new int[row][column];
    }

    void nhap() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ma tran: ");
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                System.out.println("Nhap phan tu [" + (i + 1) + "][" + (j + 1) + "]: ");
                a[i][j] = sc.nextInt();
            }
        }
    }

    void showInfo() {

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                System.out.printf("%d     ", a[i][j]);
            }
            System.out.println();
        }
    }

    void xoayPhai90() {
        for (int i = 0; i < column; i++) {
            for (int j = 0; j < row; j++) {
                System.out.printf("%d     ", a[row - 1 - j][i]);
            }
            System.out.println();
        }
        System.out.println();
    }

    void xoay180() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                System.out.printf("%d     ", a[row - 1 - i][column - 1 - j]);
            }
            System.out.println();
        }
        System.out.println();
    }

    void xoayTrai90() {
        for (int i = 0; i < column; i++) {
            for (int j = 0; j < row; j++) {
                System.out.printf("%d     ", a[j][column - 1 - i]);
            }
            System.out.println("");
        }
        System.out.println("");
    }
}
