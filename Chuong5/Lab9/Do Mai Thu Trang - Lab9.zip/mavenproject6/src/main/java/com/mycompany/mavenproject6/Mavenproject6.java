/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject6;

/**
 *
 * @author Admin
 */

import java.util.Scanner;

public class Mavenproject6 {

    public static void main(String[] args) {
        
    }
}
