/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject6;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Solution {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            Matrix mat = new Matrix();
            mat.inputInfo();
            mat.nhap();
            System.out.println("Ma tran: ");
            mat.showInfo();
            System.out.println("Ma tran sau khi xoay phai 90 do la: ");
            mat.xoayPhai90();
            System.out.println("Ma tran sau khi xoay 180 do la: ");
            mat.xoay180();
            System.out.println("Ma tran sau khi xoay trai 90 do la: ");
            mat.xoayTrai90();
        }
    }
}
