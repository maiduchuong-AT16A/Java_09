/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hinhchunhat;

/**
 *
 * @author Admin
 */
public class NewClass {
    public static void main(String[] args) {
        HinhChuNhat hinhchunhat1 = new HinhChuNhat();
        hinhchunhat1.input();
        hinhchunhat1.output();;
    }
}
