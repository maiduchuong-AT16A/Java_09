/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.oop5520041;

/**
 *
 * @author Admin
 */
public class OOP5520041 {

    public static void main(String[] args) {
        
    }
}
