/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.oop5520041;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Student {
    String masv;
    double diemtb;
    int namsinh;
    String lop;

    public Student() {
        super();
    }

    public Student(String masv, double diemtb, int namsinh, String lop) {
        super();
        this.masv = masv;
        this.diemtb = diemtb;
        this.namsinh = namsinh;
        this.lop = lop;
    }
    void inputInfo(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Nhap thong tin sinh vien");
        System.out.println("nhap ma sinh vien:");
        masv=sc.nextLine();
        System.out.println("nhap diem trung binh:");
        diemtb=sc.nextDouble();
        System.out.println("nhap nam sinh:");
        namsinh=sc.nextInt();
        sc.nextLine();
        System.out.println("nhap lop:");
        lop=sc.nextLine();
    }
    void showInfo(){
        System.out.print("ma sinh vien:");
        System.out.println(masv);
        System.out.printf("diem trung binh:%.1f",diemtb);
        System.out.printf("\n");
        System.out.printf("nam sinh:%d",namsinh);
        System.out.printf("\n");
        System.out.print("lop:");
        System.out.println(lop);
        
        
    }
    void checkScholapship(){
        if(diemtb>=8){
            System.out.println("true");
        }
        else if(diemtb<8){
            System.out.println("false");
            
        }
    }
    
    
}
