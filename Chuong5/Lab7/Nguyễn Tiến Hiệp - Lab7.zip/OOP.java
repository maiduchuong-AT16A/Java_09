
package com.mycompany.oop;

import java.util.Scanner;

public class OOP 
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("===== Nhap do dai hinh chu nhat =====");
        double a = sc.nextDouble();
        double b = sc.nextDouble();
        solve hinh1 = new solve(a, b);
        hinh1.output();
    }
}
