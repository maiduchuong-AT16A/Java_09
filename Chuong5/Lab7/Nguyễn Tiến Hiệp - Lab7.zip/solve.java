
package com.mycompany.oop;

import java.util.Scanner;

public class solve 
{
    double a;
    double b;
    public solve()
    {
        
    }
    public solve(double a, double b) 
    {
        this.a = a;
        this.b = b;
    }
    void input()
    {
        Scanner sc = new Scanner(System.in);
        a = sc.nextDouble();
        b = sc.nextDouble();
    }
    double chuVi()
    {
        double cv = 2*(a+b);
        return cv;
    }
    double dienTich()
    {
        double dt = a*b;
        return dt;
    }
    void output()
    {
        System.out.println("Chu vi = " + chuVi());
        System.out.println("Dien tich = " + dienTich());
    }
}
