/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.phanso;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class PhanSo {
  int a,b;
  public PhanSo(){
      super();
  }

    public PhanSo(int a, int b) {
        this.a = a;
        this.b = b;
    }
  
    void input(){
        Scanner SC = new Scanner(System.in);
        System.out.println("Nhap vao tu so");
        a = SC.nextInt();
        System.out.println("NHap vao mau so");
        b = SC.nextInt();
    }
    int ucll(int a,int b){
        int r;
        while(b != 0){
        r = a%b;
        a = b;
        b = r;
        }
        return a;
    }
    void rutgonphanso(){
        int c = ucll(a,b);
        a = a/c;
        b = b/c;
    }
    void output(){
        rutgonphanso();
        System.out.printf("Phan so la: %d/%d\n",a,b);
        System.out.printf("Phan so nghich dao la: %d/%d\n",b,a);
    }
  
    
}
