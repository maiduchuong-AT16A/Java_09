/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.phanso;

/**
 *
 * @author ACER
 */
public class phanso1 {
     public static void main(String[] args) {
       //PhanSo ps = new PhanSo(4,5);
       PhanSo ps = new PhanSo();
       ps.input();
       ps.output();
     
    }
    
}
