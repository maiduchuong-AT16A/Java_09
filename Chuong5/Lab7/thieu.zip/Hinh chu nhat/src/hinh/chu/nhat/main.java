package hinh.chu.nhat;

import java.util.Scanner;

public class main {
       public int dai;
       public int rong;
       
       public void input()
       {
           Scanner sc = new Scanner(System.in);
           System.out.printf("Nhap chieu dai: ");
           dai = sc.nextInt();
           System.out.printf("Nhap chieu rong: ");
           rong = sc.nextInt();
       }
       public void output()
       {
           int cv = (dai+rong)*2;
           System.out.printf("Chu vi = %d\n", cv);
           int dt = dai*rong;
           System.out.printf("Dien tich = %d\n", dt);
       }
           
}
