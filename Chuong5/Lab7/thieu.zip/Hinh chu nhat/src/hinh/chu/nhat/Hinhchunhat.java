
package hinh.chu.nhat;


public class Hinhchunhat {
    public static void main(String[] args)
    {
        main tgiac = new main();
        tgiac.input();
        tgiac.output();
    }
}
