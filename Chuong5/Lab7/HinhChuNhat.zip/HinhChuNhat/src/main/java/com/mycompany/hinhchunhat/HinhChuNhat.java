/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.hinhchunhat;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class HinhChuNhat {

    double chieuDai;
    double chieuRong;

    public HinhChuNhat(double chieuDai, double chieuRong) {
        this.chieuDai = chieuDai;
        this.chieuRong = chieuRong;
    }

    public HinhChuNhat() {

    }

    void input() {
        Scanner SC = new Scanner(System.in);
        System.out.println("Chieu dai");
        chieuDai = SC.nextDouble();
        chieuRong = SC.nextDouble();
    }

    double tinhChuVi() {
        double chuVi = 2 * (chieuDai + chieuRong);
        return chuVi;
    }

    double tinhDienTich() {
        double dienTich = chieuDai * chieuRong;
        return dienTich;
    }

    void output() {
        System.out.println("Chu vi tam giac la :" + tinhChuVi());
        System.out.println("Dien tich tam giac la: " + tinhDienTich());
    }

}
