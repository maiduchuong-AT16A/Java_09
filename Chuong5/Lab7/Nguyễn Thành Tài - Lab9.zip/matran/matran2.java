/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matran;

/**
 *
 * @author ACER
 */
public class matran2 {
    public static void main(String[] args) {
        
          MaTran mt1 = new MaTran();
          
          mt1.input();
          mt1.output();
          mt1.xoaytrai90();
          mt1.output();
          mt1.xoayphai90();
          mt1.output();
         
    }
    
    
}
