/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject4;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Rectangle {
    double d;
    double r;
    double p = 0;
    double s = 0;

    public Rectangle(double d, double r) {
        this.d = d;
        this.r = r;
    }

    public Rectangle() {
        
    }
    
    void inputInfo() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap du lieu: ");
        System.out.println("Nhap chieu dai hinh chu nhat: ");
        d = sc.nextDouble();
        System.out.println("Nhap chieu rong hinh chu nhat: ");
        r = sc.nextDouble();
    }
    
    void showInfo() {
        System.out.println("Hinh chu nhat co chieu dai la " + d + " va chieu rong la " + r);
    }
    
    void tinhChuVi() {
        p = (d + r) * 2;
        System.out.println("Chu vi hinh chu nhat la: " + p);
    }
    
    void tinhDienTich() {
        s = d * r;
        System.out.println("Dien tich hinh chu nhat la: " + s);
    }
}
