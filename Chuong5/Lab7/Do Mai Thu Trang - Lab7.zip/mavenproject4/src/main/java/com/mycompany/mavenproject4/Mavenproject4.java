/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.mavenproject4;

/**
 *
 * @author Admin
 */
import java.util.Scanner;

public class Mavenproject4 {

    public static void main(String[] args) {
        
    }
}
