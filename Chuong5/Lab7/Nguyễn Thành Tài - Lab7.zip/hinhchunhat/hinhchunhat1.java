/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hinhchunhat;

/**
 *
 * @author ACER
 */
public class hinhchunhat1 {
    public static void main(String[] args) {
       //HinhChuNhat hcn = new HinhChuNhat(4,5);
       HinhChuNhat hcn = new HinhChuNhat();
       hcn.input();
       hcn.output();
     
    }
    
    
}
