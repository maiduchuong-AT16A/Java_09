/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hinhchunhat;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class HinhChuNhat {
  double a,b;
    public HinhChuNhat(){
        super();
    }

    public HinhChuNhat(double dai, double rong) {
        this.a = dai;
        this.b = rong;
    }
    void input(){
       Scanner SC = new Scanner(System.in);
       System.out.println("Nhap vao chieu dai:");
       a = SC.nextDouble();
       System.out.println("Nhap vao chieu rong:");
       b = SC.nextDouble();
      
   }
    double cvi(){
        return 2*(a + b);
        
    }
    double dtc(){
        return a*b;
    }
    void output(){
        System.out.println(cvi());
        System.out.println(dtc());
    }
   
}
