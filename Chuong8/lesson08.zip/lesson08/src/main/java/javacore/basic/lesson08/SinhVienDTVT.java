/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson08;

/**
 *
 * @author Admin
 */
public class SinhVienDTVT extends SinhVien {

    double tds;
    double tkm;
    double vdk;

    public SinhVienDTVT(String ho_ten, String nganh_hoc, double tds, double tkm, double vdk) {
        super(ho_ten, nganh_hoc);
        this.tds = tds;
        this.tkm = tkm;
        this.vdk = vdk;
    }

    @Override
    protected double getDiem() {
        return (vdk * 2 + tkm + tds) / 4;
    }

    public double getTds() {
        return tds;
    }

    public void setTds(double tds) {
        this.tds = tds;
    }

    public double getTkm() {
        return tkm;
    }

    public void setTkm(double tkm) {
        this.tkm = tkm;
    }

    public double getVdk() {
        return vdk;
    }

    public void setVdk(double vdk) {
        this.vdk = vdk;
    }

    public String getHo_ten() {
        return ho_ten;
    }

    public void setHo_ten(String ho_ten) {
        this.ho_ten = ho_ten;
    }

    public String getNganh_hoc() {
        return nganh_hoc;
    }

    public void setNganh_hoc(String nganh_hoc) {
        this.nganh_hoc = nganh_hoc;
    }

    protected String getHocLuc() {
        if (getDiem() < 4.0) {
            return "Yeu";
        } else if (getDiem() >= 4.0 && getDiem() < 6.0) {
            return "Trung binh";
        } else if (getDiem() >= 6.0 && getDiem() < 7.0) {
            return "Trung binh kha";
        } else if (getDiem() >= 7.0 && getDiem() < 8.0) {
            return "Kha";
        } else if (getDiem() >= 8.0 && getDiem() < 9.0) {
            return "Gioi";
        } else {
            return "Xuat sac";
        }
    }

    protected void hienThiThongTin() {
        System.out.printf("SV: %-20s - %s - %.2f - %s\n", ho_ten, nganh_hoc, getDiem(), getHocLuc());
    }
}
