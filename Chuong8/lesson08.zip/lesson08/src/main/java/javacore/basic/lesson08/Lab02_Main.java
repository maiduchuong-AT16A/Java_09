/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson08;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int T = sc.nextInt();

        for (int t = 0; t < T; t++) {
            int m = sc.nextInt();
            int n = sc.nextInt();
            int p = sc.nextInt();
            
            int x = sc.nextInt();
            int y = sc.nextInt();
            int z = sc.nextInt();

            SinhVienATTT[] attt = new SinhVienATTT[m];
            SinhVienCNTT[] cntt = new SinhVienCNTT[n];
            SinhVienDTVT[] dtvt = new SinhVienDTVT[p];

            for (int i = 0; i < m; i++) {
                sc.nextLine();
                String ten = sc.nextLine();
                double md = sc.nextDouble();
                double ltat = sc.nextDouble();
                double dts = sc.nextDouble();
                attt[i] = new SinhVienATTT(ten, "ATTT", md, ltat, dts);
            }

            for (int j = 0; j < n; j++) {
                sc.nextLine();
                String ten = sc.nextLine();
                double web = sc.nextDouble();
                double android = sc.nextDouble();
                double nhung = sc.nextDouble();
                cntt[j] = new SinhVienCNTT(ten, "CNTT", web, android, nhung);
            }

            for (int k = 0; k < p; k++) {
                sc.nextLine();
                String ten = sc.nextLine();
                double tds = sc.nextDouble();
                double tkm = sc.nextDouble();
                double vdk = sc.nextDouble();
                dtvt[k] = new SinhVienDTVT(ten, "DTVT", tds, tkm, vdk);
            }

            System.out.println("Case #" + (t + 1) + ":");

            for (int i = 0; i < m; i++) {
                if (i == x) {
                    attt[i].hienThiThongTin();
                }
            }

            for (int j = 0; j < n; j++) {
                if (j == y) {
                    cntt[j].hienThiThongTin();
                }
            }

            for (int k = 0; k < p; k++) {
                if (k == z) {
                    dtvt[k].hienThiThongTin();
                }
            }
        }
    }
}
