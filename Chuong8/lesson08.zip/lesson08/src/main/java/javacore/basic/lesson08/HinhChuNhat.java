/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson08;

/**
 *
 * @author Admin
 */
public class HinhChuNhat {

    double d;
    double r;

    public HinhChuNhat() {

    }

    public HinhChuNhat(double d, double r) {
        this.d = d;
        this.r = r;
    }

    public double getD() {
        return d;
    }

    public void setD(double d) {
        this.d = d;
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }

    protected double getChuVi() {
        return (2 * (d + r) * 1000) / 1000;
    }

    protected double getDienTich() {
        return (d * r * 1000) / 1000;
    }

    protected void hienThiThongTin() {
        System.out.printf("HCN(%.06f, %.06f): chu vi = %.03f, dien tich = %.03f\n", d, r, getChuVi(), getDienTich());
    }
}
