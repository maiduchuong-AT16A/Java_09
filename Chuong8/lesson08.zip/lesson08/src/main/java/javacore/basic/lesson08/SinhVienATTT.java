/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson08;

/**
 *
 * @author Admin
 */
public class SinhVienATTT extends SinhVien {

    double md;
    double ltat;
    double dts;

    public SinhVienATTT(String ho_ten, String nganh_hoc, double md, double ltat, double dts) {
        super(ho_ten, nganh_hoc);
        this.md = md;
        this.ltat = ltat;
        this.dts = dts;
    }

    @Override
    protected double getDiem() {
        return (md * 2 + ltat * 2 + dts) / 5;
    }

    public double getMd() {
        return md;
    }

    public void setMd(double md) {
        this.md = md;
    }

    public double getLtat() {
        return ltat;
    }

    public void setLtat(double ltat) {
        this.ltat = ltat;
    }

    public double getDts() {
        return dts;
    }

    public void setDts(double dts) {
        this.dts = dts;
    }

    public String getHo_ten() {
        return ho_ten;
    }

    public void setHo_ten(String ho_ten) {
        this.ho_ten = ho_ten;
    }

    public String getNganh_hoc() {
        return nganh_hoc;
    }

    public void setNganh_hoc(String nganh_hoc) {
        this.nganh_hoc = nganh_hoc;
    }

    protected String getHocLuc() {
        if (getDiem() < 4.0) {
            return "Yeu";
        } else if (getDiem() >= 4.0 && getDiem() < 6.0) {
            return "Trung binh";
        } else if (getDiem() >= 6.0 && getDiem() < 7.0) {
            return "Trung binh kha";
        } else if (getDiem() >= 7.0 && getDiem() < 8.0) {
            return "Kha";
        } else if (getDiem() >= 8.0 && getDiem() < 9.0) {
            return "Gioi";
        } else {
            return "Xuat sac";
        }
    }

    protected void hienThiThongTin() {
        System.out.printf("SV: %-20s - %s - %.2f - %s\n", ho_ten, nganh_hoc, getDiem(), getHocLuc());
    }
}
