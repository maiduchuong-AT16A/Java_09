/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package javacore.basic.lesson08;

/**
 *
 * @author Admin
 */
public class Lesson08 {

    public static void main(String[] args) {

    }
}
