/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson08;

/**
 *
 * @author Admin
 */
public class HinhVuong extends HinhChuNhat {

    double canh;

    public HinhVuong() {

    }

    public HinhVuong(double canh) {
        this.canh = canh;
    }

    public double getCanh() {
        return canh;
    }

    public void setCanh(double canh) {
        this.canh = canh;
    }

    @Override
    protected double getChuVi() {
        return (4 * canh * 1000) / 1000;
    }

    protected double getDienTich() {
        return (canh * canh * 1000) / 1000;
    }

    protected void hienThiThongTin() {
        System.out.printf("HV(canh = %.06f): chu vi = %.03f, dien tich = %.03f\n", getCanh(), getChuVi(), getDienTich());
    }
}
