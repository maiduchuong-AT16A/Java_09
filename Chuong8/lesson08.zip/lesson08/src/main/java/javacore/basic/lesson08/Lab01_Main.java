/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson08;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Lab01_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int t = sc.nextInt();

        for (int i = 0; i < t; i++) {

            int m = sc.nextInt();
            int n = sc.nextInt();
            int p = sc.nextInt();
            int q = sc.nextInt();

            double dai = 0, rong = 0, canh = 0;

            HinhChuNhat[] a = new HinhChuNhat[m];
            HinhVuong[] b = new HinhVuong[n];
            int[] c = new int[p];
            int[] d = new int[q];

            for (int j = 0; j < m; j++) {
                dai = sc.nextDouble();
                rong = sc.nextDouble();
                a[j] = new HinhChuNhat(dai, rong);
            }

            for (int k = 0; k < n; k++) {
                canh = sc.nextDouble();

                b[k] = new HinhVuong(canh);
            }

            System.out.println("Case #" + (i + 1) + ":");

            for (int l = 0; l < p; l++) {
                c[l] = sc.nextInt();

                a[c[l]].hienThiThongTin();
            }

            for (int o = 0; o < q; o++) {
                d[o] = sc.nextInt();

                b[d[o]].hienThiThongTin();
            }
        }
    }
}
